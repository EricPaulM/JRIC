import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import {
  Accessibility, Cpu, Brain, Plus, ArrowRight, Menu, X,
  Hand, Activity, Stethoscope, Mail, MapPin, Instagram, ScrollText,
  Sparkles, Users,
} from "lucide-react";
import teamPhotoFullAsset from "@/assets/team-photo-full.png.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "JKUAT Rehab Innovation Club — A future without barriers" },
      { name: "description", content: "We are the JKUAT Rehabilitation Innovation Club — co-creating affordable, accessible and intelligent rehab technologies for Africa and beyond." },
      { property: "og:title", content: "JKUAT Rehab Innovation Club — A future without barriers" },
      { property: "og:description", content: "We are the JKUAT Rehabilitation Innovation Club — co-creating affordable, accessible and intelligent rehab technologies for Africa and beyond." },
    ],
  }),
  component: Index,
});

const REGISTER_URL = "https://forms.gle/1goGr75exseBqxs36";
const WHATSAPP_URL = "https://chat.whatsapp.com/CPTULllmSjCEeYyGarjlGj";

function Index() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main>
        <Hero />
        <About />
        <AboutTeam />
        <Equation />
        <Projects />
      </main>
      <Footer />
    </div>
  );
}

function Header() {
  const [open, setOpen] = useState(false);
  const links = [
    { label: "About Us", href: "#about" },
    { label: "About the Team", href: "#team" },
    { label: "Our Equation", href: "#equation" },
    { label: "Our Projects", href: "#projects" },
    { label: "Constitution", href: "/constitution" },
  ];
  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/85 backdrop-blur-md">
      <div className="mx-auto max-w-7xl px-6 h-16 flex items-center justify-between gap-4">
        <Link to="/" className="flex items-center gap-2 min-w-0">
          <span
            aria-hidden
            className="inline-flex h-9 w-9 items-center justify-center rounded-lg font-display font-bold text-white shrink-0"
            style={{ background: "var(--gradient-primary)" }}
          >
            RIC
          </span>
          <span className="font-display font-bold text-base sm:text-lg truncate">
            JKUAT Rehab <span style={{ color: "var(--brand-blue)" }}>Innovation</span> Club
          </span>
        </Link>

        <div className="flex items-center gap-3">
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-muted-foreground">
            {links.map((l) =>
              l.href.startsWith("#") ? (
                <a key={l.label} href={l.href} className="hover:text-foreground transition">{l.label}</a>
              ) : (
                <Link key={l.label} to={l.href} className="hover:text-foreground transition">{l.label}</Link>
              )
            )}
          </nav>
          <a
            href={REGISTER_URL}
            target="_blank" rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-sm hover:opacity-90 transition"
          >
            Get Involved <ArrowRight className="h-4 w-4" />
          </a>
          <button
            type="button"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
            className="md:hidden inline-flex h-11 w-11 items-center justify-center rounded-md border border-border bg-card"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>
      {open && (
        <div className="md:hidden border-t border-border bg-background">
          <nav className="mx-auto max-w-7xl px-6 py-4 flex flex-col gap-1">
            {links.map((l) =>
              l.href.startsWith("#") ? (
                <a key={l.label} href={l.href} onClick={() => setOpen(false)}
                  className="rounded-lg px-3 py-3 text-base font-medium hover:bg-muted transition">{l.label}</a>
              ) : (
                <Link key={l.label} to={l.href} onClick={() => setOpen(false)}
                  className="rounded-lg px-3 py-3 text-base font-medium hover:bg-muted transition">{l.label}</Link>
              )
            )}
            <a href={REGISTER_URL} target="_blank" rel="noopener noreferrer"
              className="mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground">
              Get Involved <ArrowRight className="h-4 w-4" />
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden" style={{ background: "var(--gradient-hero)" }}>
      <div className="mx-auto max-w-6xl px-6 pt-20 pb-24 lg:pt-28 lg:pb-32 text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground shadow-sm">
          <Sparkles className="h-3.5 w-3.5" style={{ color: "var(--brand-orange)" }} />
          Student-led · Multi-disciplinary · Impact-driven
        </div>
        <h1 className="mt-6 font-display text-5xl sm:text-6xl lg:text-7xl font-bold leading-[1.05] tracking-tight max-w-4xl mx-auto">
          A future <span style={{ color: "var(--brand-orange)" }}>without barriers</span>,
          <br className="hidden sm:block" /> powered by <span style={{ color: "var(--brand-blue)" }}>inclusive tech</span>.
        </h1>
        <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto">
          We are the JKUAT Rehabilitation Innovation Club — co-creating affordable, accessible and
          intelligent rehab technologies for Africa and beyond.
        </p>
        <div className="mt-9 flex flex-wrap justify-center gap-3">
          <a
            href="#projects"
            className="inline-flex items-center gap-2 rounded-full px-6 py-3 font-semibold text-primary-foreground transition hover:opacity-90"
            style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-glow)" }}
          >
            Explore Projects <ArrowRight className="h-4 w-4" />
          </a>
          <a
            href={REGISTER_URL}
            target="_blank" rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-full border-2 px-6 py-3 font-semibold transition hover:bg-secondary hover:text-secondary-foreground"
            style={{ borderColor: "var(--brand-blue)", color: "var(--brand-blue)" }}
          >
            Join the Club
          </a>
        </div>
      </div>
    </section>
  );
}

function About() {
  return (
    <section id="about" className="mx-auto max-w-6xl px-6 py-20 lg:py-24">
      <div className="grid lg:grid-cols-[1.1fr_1fr] gap-12 items-center">
        <div>
          <p className="text-xs font-bold uppercase tracking-widest" style={{ color: "var(--brand-blue)" }}>
            About Us
          </p>
          <h2 className="mt-3 font-display text-3xl lg:text-5xl font-bold leading-tight">
            Co-creating rehab tech that meets Africa's realities.
          </h2>
          <p className="mt-5 text-base lg:text-lg text-muted-foreground max-w-xl">
            We are the JKUAT Rehabilitation Innovation Club — co-creating affordable, accessible and
            intelligent rehab technologies for Africa and beyond. Our members bridge the clinic, the
            workshop and the lab to build tools people actually use.
          </p>
          <div className="mt-8 grid grid-cols-3 gap-4 max-w-md">
            {[
              { k: "3", v: "Disciplines" },
              { k: "1", v: "Mission" },
              { k: "∞", v: "Impact" },
            ].map((s) => (
              <div key={s.v} className="rounded-2xl border border-border bg-card p-4 text-center shadow-sm">
                <div className="font-display text-3xl font-bold" style={{ color: "var(--brand-orange)" }}>{s.k}</div>
                <div className="mt-1 text-xs font-medium text-muted-foreground">{s.v}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="relative">
          <div
            className="rounded-3xl border border-border p-8 lg:p-10 bg-card"
            style={{ boxShadow: "var(--shadow-card)" }}
          >
            <div className="space-y-5">
              {[
                { icon: Accessibility, text: "Designed with — not for — the people we serve." },
                { icon: Cpu, text: "Locally engineered, globally relevant." },
                { icon: Brain, text: "Intelligent systems that adapt to each patient." },
              ].map(({ icon: Icon, text }) => (
                <div key={text} className="flex items-start gap-4">
                  <span
                    className="inline-flex h-11 w-11 items-center justify-center rounded-xl shrink-0"
                    style={{ background: "rgba(2,132,199,0.12)", color: "var(--brand-blue)" }}
                  >
                    <Icon className="h-5 w-5" />
                  </span>
                  <p className="text-base font-medium">{text}</p>
                </div>
              ))}
            </div>
          </div>
          <div
            aria-hidden
            className="absolute -bottom-6 -right-6 h-28 w-28 rounded-3xl -z-10"
            style={{ background: "var(--gradient-primary)", opacity: 0.15 }}
          />
        </div>
      </div>
    </section>
  );
}

function AboutTeam() {
  return (
    <section id="team" className="border-y border-border bg-muted/30">
      <div className="mx-auto max-w-6xl px-6 py-20 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="order-2 lg:order-1">
            <div className="rounded-3xl border border-border bg-card p-3 shadow-sm" style={{ boxShadow: "var(--shadow-card)" }}>
              <img
                src={teamPhotoFullAsset.url}
                alt="JKUAT Rehabilitation Innovation Club members standing together in front of the College of Health Sciences Complex"
                className="w-full rounded-2xl object-cover"
                loading="lazy"
              />
            </div>
          </div>
          <div className="order-1 lg:order-2">
            <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground shadow-sm">
              <Users className="h-3.5 w-3.5" style={{ color: "var(--brand-orange)" }} />
              Meet the Team
            </div>
            <h2 className="mt-4 font-display text-3xl lg:text-5xl font-bold leading-tight">
              The people behind the mission.
            </h2>
            <p className="mt-5 text-base lg:text-lg text-muted-foreground max-w-xl">
              We are a diverse, student-led team from JKUAT's College of Health Sciences, School of
              Engineering and School of Computing & IT. Together we bring clinical insight, technical
              skill and lived experience to every project we build.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              {[
                "Rehabilitation Sciences",
                "Biomedical Engineering",
                "ICT & AI",
                "Community Outreach",
              ].map((tag) => (
                <span
                  key={tag}
                  className="inline-flex items-center rounded-full border border-border bg-card px-4 py-2 text-sm font-medium text-muted-foreground"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function EquationBlock({
  icon: Icon, label, tint,
}: { icon: React.ComponentType<{ className?: string }>; label: string; tint: string }) {
  return (
    <div
      className="rounded-2xl border border-border bg-card px-6 py-8 text-center flex-1 min-w-[180px] transition hover:-translate-y-1"
      style={{ boxShadow: "var(--shadow-card)" }}
    >
      <span
        className="mx-auto inline-flex h-14 w-14 items-center justify-center rounded-2xl"
        style={{ background: `${tint}1F`, color: tint }}
      >
        <Icon className="h-7 w-7" />
      </span>
      <div className="mt-4 font-display text-lg font-bold">{label}</div>
    </div>
  );
}

function Equation() {
  return (
    <section id="equation" className="border-y border-border bg-muted/50">
      <div className="mx-auto max-w-6xl px-6 py-20 lg:py-24">
        <div className="text-center max-w-2xl mx-auto">
          <p className="text-xs font-bold uppercase tracking-widest" style={{ color: "var(--brand-orange)" }}>
            Our Equation
          </p>
          <h2 className="mt-3 font-display text-3xl lg:text-5xl font-bold">
            How we turn disciplines into solutions.
          </h2>
          <p className="mt-4 text-muted-foreground">
            Rehabilitation Sciences + Engineering + ICT / AI = innovative solutions for real-world challenges.
          </p>
        </div>

        <div className="mt-14 flex flex-col lg:flex-row items-stretch justify-center gap-4">
          <EquationBlock icon={Accessibility} label="Rehabilitation Sciences" tint="#0284C7" />
          <Operator symbol="plus" />
          <EquationBlock icon={Cpu} label="Engineering" tint="#0F172A" />
          <Operator symbol="plus" />
          <EquationBlock icon={Brain} label="ICT / AI" tint="#0284C7" />
          <Operator symbol="equals" />
          <div
            className="flex-1 min-w-[200px] rounded-2xl px-6 py-8 text-center text-primary-foreground"
            style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-glow)" }}
          >
            <span className="mx-auto inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-white/20">
              <Sparkles className="h-7 w-7" />
            </span>
            <div className="mt-4 font-display text-lg font-bold">Innovative Solutions</div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Operator({ symbol }: { symbol: "plus" | "equals" }) {
  return (
    <div className="flex items-center justify-center py-2 lg:py-0" aria-hidden>
      {symbol === "plus" ? (
        <Plus className="h-7 w-7 text-muted-foreground" strokeWidth={2.5} />
      ) : (
        <span className="font-display text-3xl font-bold text-muted-foreground">=</span>
      )}
    </div>
  );
}

const PROJECTS = [
  {
    icon: Hand,
    tag: "Assistive Devices",
    title: "Affordable Prosthetics",
    desc: "Locally manufacturable prosthetics designed with amputees, clinicians and engineers.",
  },
  {
    icon: Brain,
    tag: "AI & Diagnostics",
    title: "AI-Driven Rehab Diagnostics",
    desc: "Intelligent tools that help clinicians assess progress and tailor treatment faster.",
  },
  {
    icon: Activity,
    tag: "Smart Therapy",
    title: "Connected Therapy Tools",
    desc: "Sensor-driven devices that guide, measure and motivate rehab at home and in clinic.",
  },
];

function Projects() {
  return (
    <section id="projects" className="mx-auto max-w-6xl px-6 py-20 lg:py-24">
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-6">
        <div className="max-w-xl">
          <p className="text-xs font-bold uppercase tracking-widest" style={{ color: "var(--brand-blue)" }}>
            Our Projects
          </p>
          <h2 className="mt-3 font-display text-3xl lg:text-5xl font-bold leading-tight">
            Focus areas we're building today.
          </h2>
        </div>
        <a
          href={REGISTER_URL}
          target="_blank" rel="noopener noreferrer"
          className="inline-flex items-center gap-2 text-sm font-semibold"
          style={{ color: "var(--brand-orange)" }}
        >
          Get involved <ArrowRight className="h-4 w-4" />
        </a>
      </div>

      <div className="mt-10 grid md:grid-cols-3 gap-5">
        {PROJECTS.map(({ icon: Icon, tag, title, desc }) => (
          <article
            key={title}
            className="group rounded-2xl border border-border bg-card p-7 transition duration-300 hover:-translate-y-1 hover:border-primary/50"
            style={{ boxShadow: "var(--shadow-card)" }}
          >
            <span
              className="inline-flex h-12 w-12 items-center justify-center rounded-xl transition group-hover:scale-110"
              style={{ background: "rgba(2,132,199,0.12)", color: "var(--brand-blue)" }}
            >
              <Icon className="h-6 w-6" />
            </span>
            <p className="mt-5 text-xs font-bold uppercase tracking-widest text-muted-foreground">{tag}</p>
            <h3 className="mt-1 font-display text-xl font-bold">{title}</h3>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{desc}</p>
          </article>
        ))}
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="text-white" style={{ background: "var(--brand-obsidian)" }}>
      <div className="mx-auto max-w-7xl px-6 py-14 grid gap-10 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2">
            <span
              className="inline-flex h-9 w-9 items-center justify-center rounded-lg font-display font-bold"
              style={{ background: "var(--gradient-primary)" }}
            >
              RIC
            </span>
            <span className="font-display font-bold text-lg">JKUAT Rehab Innovation Club</span>
          </div>
          <p className="mt-4 max-w-md text-sm text-white/70">
            A student-led club at Jomo Kenyatta University of Agriculture and Technology, uniting
            Rehabilitation Sciences, Engineering and ICT/AI to build a future without barriers.
          </p>
          <div className="mt-5 flex items-start gap-2 text-sm text-white/70">
            <MapPin className="h-4 w-4 mt-0.5 shrink-0" style={{ color: "var(--brand-orange)" }} />
            <span>JKUAT Main Campus · Juja, Kiambu County, Kenya</span>
          </div>
          <div className="mt-2 flex items-start gap-2 text-sm text-white/70">
            <Stethoscope className="h-4 w-4 mt-0.5 shrink-0" style={{ color: "var(--brand-orange)" }} />
            <span>College of Health Sciences × School of Engineering × School of Computing & IT</span>
          </div>
        </div>

        <div>
          <p className="text-xs font-bold uppercase tracking-widest text-white/60">Explore</p>
          <ul className="mt-4 space-y-2 text-sm">
            <li><a href="#about" className="text-white/80 hover:text-white">About Us</a></li>
            <li><a href="#team" className="text-white/80 hover:text-white">About the Team</a></li>
            <li><a href="#equation" className="text-white/80 hover:text-white">Our Equation</a></li>
            <li><a href="#projects" className="text-white/80 hover:text-white">Our Projects</a></li>
            <li><Link to="/constitution" className="text-white/80 hover:text-white inline-flex items-center gap-1.5">
              <ScrollText className="h-4 w-4" /> Constitution
            </Link></li>
          </ul>
        </div>

        <div>
          <p className="text-xs font-bold uppercase tracking-widest text-white/60">Get in touch</p>
          <ul className="mt-4 space-y-2 text-sm">
            <li>
              <a href={REGISTER_URL} target="_blank" rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold text-primary-foreground"
                style={{ background: "var(--gradient-primary)" }}>
                Get Involved <ArrowRight className="h-4 w-4" />
              </a>
            </li>
            <li>
              <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer"
                className="text-white/80 hover:text-white inline-flex items-center gap-2">
                <Instagram className="h-4 w-4" /> Community WhatsApp
              </a>
            </li>
            <li>
              <a href="mailto:jric@jkuat.ac.ke" className="text-white/80 hover:text-white inline-flex items-center gap-2">
                <Mail className="h-4 w-4" /> jric@jkuat.ac.ke
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="mx-auto max-w-7xl px-6 py-5 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-white/60">
          <p>© {new Date().getFullYear()} JKUAT Rehabilitation Innovation Club. All rights reserved.</p>
          <p>Built with inclusive tech · A future without barriers.</p>
        </div>
      </div>
    </footer>
  );
}
