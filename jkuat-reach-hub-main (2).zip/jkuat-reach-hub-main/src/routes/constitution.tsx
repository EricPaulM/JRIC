import { createFileRoute, Link } from "@tanstack/react-router";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ArrowLeft, ScrollText, Scale, Users, Briefcase, Calendar, Vote, Wallet, MapPin, ShieldCheck, HeartHandshake, Gavel, FileEdit, AlertCircle, Lightbulb, Accessibility } from "lucide-react";

export const Route = createFileRoute("/constitution")({
  head: () => ({
    meta: [
      { title: "Constitution & By-Laws — JRIC" },
      { name: "description", content: "The JKUAT Rehab Innovators Club constitution, by-laws, and code of conduct. Know the rules, rights, and responsibilities of every member." },
      { property: "og:title", content: "JRIC Constitution & By-Laws" },
      { property: "og:description", content: "Rules, rights, and responsibilities for every JRIC member." },
    ],
  }),
  component: ConstitutionPage,
});

const SECTIONS = [
  {
    id: "name",
    icon: ScrollText,
    title: "I. Name",
    body: (
      <p>The name of the club shall be the <strong>JKUAT Rehab Innovators Club</strong>, abbreviated as <strong>JRIC</strong>, hereafter referred to as "the Club".</p>
    ),
  },
  {
    id: "objects",
    icon: Lightbulb,
    title: "II. Objects",
    body: (
      <>
        <p>The aims of the Club are to promote rehabilitation-focused innovation, creativity, research, assistive technology, inclusivity and professional development among JKUAT students. In pursuance of its aims, the Club shall:</p>
        <ul>
          <li>Foster creativity and innovation in physiotherapy, rehabilitation sciences, and related health disciplines.</li>
          <li>Promote research, evidence-based problem solving, and knowledge sharing among students, staff, professionals and stakeholders.</li>
          <li>Develop solutions, designs and prototypes that address rehabilitation challenges, including improvements to existing rehabilitation equipment.</li>
          <li>Promote inclusivity and accessibility for all, including persons with disabilities, through advocacy and ethical assistive technology.</li>
          <li>Create a platform for mentorship, professional growth, networking and exposure to health innovation pathways.</li>
          <li>Organize workshops, seminars, hackathons, innovation challenges, exhibitions and outreach programs approved by the University.</li>
          <li>Support safe, ethical and responsible innovation aligned with University policies and fair recognition of contributors.</li>
        </ul>
      </>
    ),
  },
  {
    id: "membership",
    icon: Users,
    title: "III. Membership",
    body: (
      <>
        <p>Membership is open to all JKUAT students who support the objects of the Club and comply with this Constitution, Club by-laws and University rules.</p>
        <h4>Categories</h4>
        <ul>
          <li><strong>Full Membership</strong> — JKUAT students who have registered, paid the approved fee, and are eligible to vote and hold office.</li>
          <li><strong>Associate Membership</strong> — JKUAT students from disciplines outside physiotherapy or health sciences who are interested in rehabilitation and health innovation.</li>
          <li><strong>Honorary Membership</strong> — Alumni, faculty, mentors or external professionals admitted by the Executive Committee for advisory or technical support.</li>
        </ul>
        <h4>Fees</h4>
        <p>Membership fee: <strong>KES 100 per semester</strong>, subject to amendment by a General Meeting.</p>
        <h4>Rights & Responsibilities</h4>
        <p>Every member has the right to attend meetings, participate in activities, vote where eligible, and be treated without discrimination. Every member shall uphold the Club's objects, respect other members, protect Club property, keep member information confidential, and comply with University policies.</p>
      </>
    ),
  },
  {
    id: "executive",
    icon: Briefcase,
    title: "IV. The Executive Committee",
    body: (
      <>
        <p>The day-to-day management of the Club is vested in the Executive Committee, elected by members. The Club is spearheaded by <strong>Group Patron Dr Wallace Karuguti</strong> (0739 968 856), who provides strategic oversight and mentorship. The Executive Committee consists of the following offices:</p>
        <div className="not-prose mt-4 overflow-x-auto rounded-xl border border-border">
          <table className="w-full text-sm">
            <thead className="bg-secondary/50">
              <tr>
                <th className="px-4 py-3 text-left font-semibold">Office</th>
                <th className="px-4 py-3 text-left font-semibold">Current Holder</th>
                <th className="px-4 py-3 text-left font-semibold">Main Responsibilities</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {[
                ["President", "Lawi Barasa", "0704 266 487", "Overall leadership; represents the Club; chairs meetings; coordinates partnerships; signing authority."],
                ["Vice President", "Grace Mumbua", "0715 096 768", "Assists the President; acts in their absence; coordinates innovation workflow and project teams."],
                ["Secretary General", "Joy Manyara", "0706 699 249", "Keeps minutes, records, correspondence, membership registers, project & collaboration records."],
                ["Treasurer", "Seby Sanaipei", "0704 169 792", "Manages finances, budgets, receipts, payments, grants and resource allocation; signing authority."],
                ["Projects & Innovation Coordinator", "Austine Mulongo", "0702 283 120", "Coordinates research, design thinking, prototyping, testing and evaluation activities."],
                ["Public Relations Officer", "Erick", "0745 470 919", "Handles publicity, member communication, social media, outreach and stakeholder engagement."],
                ["Assistant", "Benard Ayieko", "0707 801 926", "Supports the Executive Committee with logistics, coordination, and assigned duties."],
                ["Welfare & Events Coordinator", "Michelle Muthoni", "0713 586 559", "Coordinates member welfare, event logistics, accessibility arrangements and inclusion measures."],
              ].map(([o, h, c, r]) => (
                <tr key={o}>
                  <td className="px-4 py-3 font-semibold text-foreground align-top">{o}</td>
                  <td className="px-4 py-3 text-foreground align-top">
                    <div className="font-medium">{h}</div>
                    <div className="text-xs text-muted-foreground">{c}</div>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">{r}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-4">Executive meetings shall be held at least once every two weeks during active project periods. Quorum is three members. The Club complies with the two-thirds gender rule under the Constitution of Kenya and the JKUAT Clubs and Societies Handbook.</p>
      </>
    ),
  },
  {
    id: "meetings",
    icon: Calendar,
    title: "V. General Meetings",
    body: (
      <ul>
        <li>The Club shall hold regular general meetings at least once every month during the semester.</li>
        <li>An Annual General Meeting (AGM) shall be held in the first month of the second semester of every academic year.</li>
        <li>Notice for general meetings shall be issued in advance and meetings are open to all members.</li>
        <li>Members shall be informed of agenda items, financial reports, project reports and elections where applicable.</li>
      </ul>
    ),
  },
  {
    id: "elections",
    icon: Vote,
    title: "VI. Elections & Tenure",
    body: (
      <ul>
        <li>Candidates for office shall be active members in good standing, proposed and seconded by two other active members.</li>
        <li>Voting shall be by secret ballot. The candidate with the highest valid votes is elected; ties trigger a re-election.</li>
        <li>The Patron/Matron acts as chief electoral officer and signs the list of elected officials submitted to the Dean of Students.</li>
        <li>Tenure is one academic year, with eligibility for re-election.</li>
        <li>Vacancies may be filled through a by-election or interim appointment ratified at the next General Meeting.</li>
      </ul>
    ),
  },
  {
    id: "finance",
    icon: Wallet,
    title: "VII. Financial Matters",
    body: (
      <ul>
        <li>The Club shall maintain a bank account in its full name, preferably with KCB, per the JKUAT Clubs and Societies policy.</li>
        <li>Funds may come from membership fees, University support, sponsorships, donations, fundraising and grants.</li>
        <li>Three signing authorities: <strong>Patron/Matron, President and Treasurer</strong>. No withdrawal without required signatures.</li>
        <li>All funds received shall be banked promptly and recorded in the Receipts and Payments Book or an approved electronic record.</li>
        <li>Annual financial reports shall be presented at the AGM and submitted as required by the University.</li>
      </ul>
    ),
  },
  {
    id: "events",
    icon: MapPin,
    title: "VIII. Activities, Events & Space Booking",
    body: (
      <ul>
        <li>University rooms and facilities shall be booked only by authorized signing officers in line with University policy.</li>
        <li>Requests for space shall be made at least <strong>14 working days</strong> before the event, unless instructed otherwise.</li>
        <li>External guests, speakers or partners must be notified to the Vice Chancellor through the Dean of Students.</li>
        <li>Non-resident attendees: the Director of Security Services shall be notified at least <strong>3 working days</strong> in advance.</li>
        <li>Sponsorships shall not compromise members' privacy, Club independence, or the Club's non-profit character.</li>
      </ul>
    ),
  },
  {
    id: "data",
    icon: ShieldCheck,
    title: "IX. Data Protection",
    body: (
      <ul>
        <li>Personal data of members is collected only for lawful Club purposes and stored securely.</li>
        <li>Member contact details shall not be shared with sponsors or external bodies without explicit consent.</li>
        <li>The Club complies with the Data Protection Act (Kenya) and JKUAT data handling guidelines.</li>
      </ul>
    ),
  },
  {
    id: "safety",
    icon: HeartHandshake,
    title: "X. Health & Safety",
    body: (
      <ul>
        <li>The Club complies with University instructions, laboratory/workshop safety rules, public-health guidance and security instructions.</li>
        <li>No member shall test, demonstrate or use equipment in a way that exposes participants to unreasonable risk or violates ethical standards.</li>
        <li>Accessibility and inclusion arrangements shall be considered in every event and project.</li>
      </ul>
    ),
  },
  {
    id: "discipline",
    icon: Gavel,
    title: "XI. Complaints & Disciplinary Process",
    body: (
      <>
        <p>Members shall conduct themselves with respect, professionalism, fairness and integrity. The following are not tolerated: discrimination, harassment, bullying, intimidation, violence, corruption, misuse of funds, plagiarism, theft of intellectual work, or unsafe conduct.</p>
        <ul>
          <li>Discrimination or harassment complaints may be made to the University Ombudsman.</li>
          <li>Other complaints may be reported to the Executive Committee or the Dean of Students.</li>
          <li>Sanctions: <strong>warning, suspension, or expulsion</strong>, depending on severity.</li>
          <li>Suspension/expulsion requires a majority vote of the Executive Committee (excluding conflicted officers). The affected member shall be informed of the allegations and given an opportunity to respond.</li>
          <li>An expelled or suspended member shall return Club property, documents, data and funds within 7 days.</li>
        </ul>
      </>
    ),
  },
  {
    id: "amendments",
    icon: FileEdit,
    title: "XII. Changes to the Constitution",
    body: (
      <ul>
        <li>Amendments may be proposed by the Executive Committee or by a written request from at least 10 active members.</li>
        <li>Amendments require a two-thirds majority of members present and voting at a General Meeting.</li>
        <li>Any amendment takes effect only after approval through required Club and University procedures.</li>
      </ul>
    ),
  },
  {
    id: "dissolution",
    icon: AlertCircle,
    title: "XIII. Dissolution",
    body: (
      <ul>
        <li>The Club may be dissolved at a General Meeting after at least 21 days' written notice.</li>
        <li>Dissolution requires a two-thirds vote of members present and voting.</li>
        <li>Remaining assets after liabilities shall be transferred to another registered University club or to the Clubs' Council.</li>
      </ul>
    ),
  },
];

const BYLAWS = [
  {
    id: "attendance",
    icon: Calendar,
    title: "Meetings & Attendance",
    body: (
      <ul>
        <li>General meetings normally held once every month during the semester.</li>
        <li>Project and task meetings may be scheduled by project teams, with notice to the Projects & Innovation Coordinator.</li>
        <li>Members should communicate apologies before missing a meeting. Repeated absence without apology may affect active membership status.</li>
        <li>Members are expected to arrive on time. Any monetary fine for persistent lateness must be reasonable, receipted and recorded as Club income.</li>
      </ul>
    ),
  },
  {
    id: "decisions",
    icon: Scale,
    title: "Decision Making",
    body: (
      <ul>
        <li>Routine administrative decisions may be made by the Executive Committee.</li>
        <li>Major decisions affecting the Constitution, finances, elections, dissolution or partnerships require General Meeting approval.</li>
        <li>All decisions shall be transparent, documented in minutes, and communicated to members.</li>
      </ul>
    ),
  },
  {
    id: "ip",
    icon: Lightbulb,
    title: "Innovation, Projects & Intellectual Property",
    body: (
      <ul>
        <li>All projects shall align with the Club's mission and comply with University research and ethics policies.</li>
        <li>Contributors shall be fairly credited. IP arising from Club projects is governed by JKUAT IP policy.</li>
        <li>Pilot testing of assistive technology shall follow safety, consent and ethical guidelines.</li>
        <li>External collaborations require Executive Committee approval and, where applicable, University endorsement.</li>
      </ul>
    ),
  },
  {
    id: "inclusion",
    icon: Accessibility,
    title: "Inclusion & Accessibility",
    body: (
      <ul>
        <li>The Club is committed to inclusion regardless of gender, ability, ethnicity, religion or background.</li>
        <li>Events shall consider physical access, communication access and reasonable accommodations.</li>
        <li>Members shall use respectful, person-first language and challenge discriminatory behavior.</li>
      </ul>
    ),
  },
];

function ConstitutionPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="border-b border-border bg-card/30">
        <div className="mx-auto max-w-5xl px-6 py-6">
          <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition">
            <ArrowLeft className="h-4 w-4" /> Back to home
          </Link>
        </div>
      </div>

      <section className="relative overflow-hidden" style={{ background: "var(--gradient-hero)" }}>
        <div className="absolute inset-0 opacity-30 pointer-events-none"
          style={{ backgroundImage: "radial-gradient(circle at 30% 50%, oklch(0.78 0.19 140 / 0.3), transparent 60%)" }} />
        <div className="relative mx-auto max-w-5xl px-6 py-16 lg:py-20">
          <div className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
            <ScrollText className="h-3.5 w-3.5" /> Governance
          </div>
          <h1 className="mt-5 font-display text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight">
            Constitution, By-Laws & <span className="text-primary">Code of Conduct</span>
          </h1>
          <p className="mt-5 text-lg text-muted-foreground max-w-2xl">
            The rules, rights and responsibilities of every JRIC member. Read carefully — by joining the Club, you agree to uphold this document.
          </p>
        </div>
      </section>

      <main className="mx-auto max-w-5xl px-6 py-16 space-y-16">
        <div>
          <div className="flex items-center gap-3 mb-6">
            <span className="rounded-md bg-primary px-2.5 py-1 text-xs font-bold text-primary-foreground">PART A</span>
            <h2 className="font-display text-3xl font-bold">Constitution</h2>
          </div>
          <Accordion type="multiple" className="space-y-3">
            {SECTIONS.map(({ id, icon: Icon, title, body }) => (
              <AccordionItem key={id} value={id}
                className="rounded-2xl border border-border bg-card px-5 data-[state=open]:border-primary/40">
                <AccordionTrigger className="hover:no-underline py-5">
                  <span className="flex items-center gap-3 text-left">
                    <span className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/15 text-primary">
                      <Icon className="h-4.5 w-4.5" />
                    </span>
                    <span className="font-display text-lg font-semibold">{title}</span>
                  </span>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="prose prose-invert max-w-none prose-headings:font-display prose-headings:text-foreground prose-h4:text-base prose-h4:mt-4 prose-h4:mb-2 prose-p:text-muted-foreground prose-li:text-muted-foreground prose-strong:text-foreground prose-ul:my-3">
                    {body}
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        <div>
          <div className="flex items-center gap-3 mb-6">
            <span className="rounded-md bg-primary px-2.5 py-1 text-xs font-bold text-primary-foreground">PART B</span>
            <h2 className="font-display text-3xl font-bold">By-Laws & Code of Conduct</h2>
          </div>
          <Accordion type="multiple" className="space-y-3">
            {BYLAWS.map(({ id, icon: Icon, title, body }) => (
              <AccordionItem key={id} value={id}
                className="rounded-2xl border border-border bg-card px-5 data-[state=open]:border-primary/40">
                <AccordionTrigger className="hover:no-underline py-5">
                  <span className="flex items-center gap-3 text-left">
                    <span className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/15 text-primary">
                      <Icon className="h-4.5 w-4.5" />
                    </span>
                    <span className="font-display text-lg font-semibold">{title}</span>
                  </span>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="prose prose-invert max-w-none prose-p:text-muted-foreground prose-li:text-muted-foreground prose-strong:text-foreground prose-ul:my-3">
                    {body}
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        <div className="rounded-2xl border border-border bg-card/50 p-6 text-sm text-muted-foreground">
          <p>
            This summary reflects the current JRIC Constitution & By-Laws draft. For the full legal text or to propose an amendment, contact the Executive Committee at{" "}
            <a href="mailto:jkuat.rehabinnovators@gmail.com" className="text-primary hover:underline">jkuat.rehabinnovators@gmail.com</a>.
          </p>
        </div>
      </main>
    </div>
  );
}
